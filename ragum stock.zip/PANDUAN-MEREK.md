# Ragum Stok — Panduan Merek

Sub-brand dari ekosistem **Ragum**. Nama lengkap: **RAGUM Stok**.

---

## Konsep

Ikonnya adalah **rahang ragum yang menjepit sebuah kotak**.

Ragum menjepit benda supaya diam dan terkendali — itu persis yang dilakukan aplikasi ini terhadap stok gudang. Kotak dengan dua garis di dalamnya membaca sebagai barang atau kardus.

Rahang dibuat miring, bukan tegak lurus. Ini disengaja: kemiringan memberi kesan sedang *menekan ke dalam*. Rahang tegak akan terbaca sebagai kurung kurawal biasa, kehilangan makna ragumnya.

---

## Sistem sub-brand

Inilah alasan konsep ini dipilih. **Rahang selalu sama, objek yang dijepit berganti** sesuai produk:

| Produk | Objek di dalam rahang |
|---|---|
| RAGUM Stok | Kotak bergaris — barang |
| RAGUM Tools | Tanda kurung kode — utilitas browser |
| RAGUM Kasir | Koin — transaksi |
| RAGUM Data | Batang grafik — laporan |

Aturannya: **jangan pernah ubah rahangnya.** Rahang adalah tanda tangan Ragum. Yang boleh diganti hanya isinya, dan isi itu harus muat dalam kotak 28×26 di tengah.

---

## Palet

Warna diambil dari material ragum sungguhan, bukan tebakan estetis.

| Warna | Kode | Asal | Pemakaian |
|---|---|---|---|
| Charcoal | `#12212B` | Besi cor | Latar gelap, teks utama |
| Biru Industri | `#1E5F8C` | Cat badan ragum | Aksi sekunder, kata "Stok" |
| Kuningan | `#E8A33D` | Ulir & handle | Aksen dan aksi utama |
| Baja | `#8FA3AE` | Rahang | Rahang di latar gelap, teks samar |
| Kertas | `#F5F3EE` | — | Latar terang |
| Bata | `#C24628` | — | Peringatan, barang keluar |

### Aturan terpenting: kuningan itu langka

Kuningan hanya boleh muncul **satu kali per layar**, pada aksi paling penting. Kalau dua tombol sama-sama kuningan, keduanya berhenti terasa penting.

Urutan hierarki:

1. **Kuningan** — aksi utama (Simpan Transaksi, Masuk)
2. **Biru** — aksi pendukung (Nyalakan Kamera, Auto)
3. **Bata** — mode barang keluar, peringatan
4. **Garis tipis** — aksi netral (Batal, Ekspor)

Ini membedakan Ragum Stok dari WANURA (Charcoal/Cream/Sage) — dua bisnismu tidak akan tertukar.

---

## Tipografi

**Poppins** — geometris, teknis, sekeluarga karakter dengan Montserrat yang dipakai WANURA.

- `RAGUM` selalu **Bold**, huruf kapital semua
- Nama produk (`Stok`) selalu **Light**, kapital di awal saja, warna biru
- Tagline: **Medium**, 10px, jarak huruf renggang (3.2)

Kontras tebal-tipis inilah yang membuat wordmark terbaca sebagai satu keluarga, bukan dua kata yang ditempel.

Tagline: **GUDANG DALAM GENGGAMAN**

---

## Berkas yang tersedia

| Berkas | Pemakaian |
|---|---|
| `ragumstok-primary.svg/png` | Ikon utama, latar terang |
| `ragumstok-app.svg/png` | Ikon aplikasi, sudut membulat |
| `ragumstok-transparent.svg/png` | Latar transparan, untuk ditumpuk |
| `ragumstok-mono_dark.svg/png` | Satu warna gelap — stempel, faktur, sablon |
| `ragumstok-mono_light.svg/png` | Satu warna terang — di atas foto gelap |
| `ragumstok-favicon.svg` | Versi sederhana untuk ukuran sangat kecil |
| `ragumstok-lockup-horizontal` | Ikon + nama, mendatar — kop surat, header situs |
| `ragumstok-lockup-stacked` | Ikon + nama, bertumpuk — media sosial, kaos |
| `ragumstok-lockup-dark` | Versi mendatar untuk latar gelap |
| `ragumstok-lockup-mono` | Satu warna — fotokopi, faks, sablon satu warna |
| `app-icons/icon-192.png`, `icon-512.png` | Ikon PWA, sudah terpasang di aplikasi |
| `app-icons/favicon.ico` | Favicon multi-ukuran (16/32/48/64) |

Semua tersedia dalam SVG. **Selalu pakai SVG kalau bisa** — bisa diperbesar sampai ukuran baliho tanpa pecah.

---

## Aturan pemakaian

**Ruang kosong.** Sisakan jarak minimal selebar rahang di semua sisi. Jangan ada elemen lain masuk ke area itu.

**Ukuran minimum.**
- Ikon penuh: 24px
- Di bawah 24px: pakai `ragumstok-favicon.svg`, versi tanpa garis di kotak

**Jangan:**
- Mengubah warna di luar palet
- Meregangkan tidak proporsional
- Menambah bayangan, gradasi, atau garis tepi
- Memutar ikon
- Menaruh ikon berwarna di atas foto ramai — pakai versi mono
- Memisahkan ikon dari nama pada lockup lalu menyusunnya sendiri

**Boleh:**
- Memakai ikon saja tanpa nama, kalau merek sudah dikenal (ikon aplikasi, favicon)
- Membalik warna untuk latar gelap
- Memakai versi mono untuk sablon atau stempel satu warna

---

## Catatan pemasangan

Ikon PWA sudah otomatis terpasang di aplikasi. Yang perlu kamu lakukan hanya menyalin folder aplikasi ke hosting — `favicon.ico`, `icon-192.png`, dan `icon-512.png` sudah ada di dalamnya.

Ikon aplikasi dibuat dengan padding 18% supaya aman saat Android memotongnya jadi lingkaran (aturan *maskable icon*). Kalau kamu mengganti ikon sendiri nanti, pertahankan padding ini — tanpa itu, rahang akan terpotong.
